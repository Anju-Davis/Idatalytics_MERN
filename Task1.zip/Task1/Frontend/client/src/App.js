import React, { useState } from 'react';
import AddTask from './components/AddTask';
import EditTask from './components/EditTask';
import TaskList from './components/TaskList';


function App() {
  const [taskToEdit, setTaskToEdit] = useState(null);

  const handleTaskAdded = () => {
    setTaskToEdit(null);
  };

  const handleTaskUpdated = () => {
    setTaskToEdit(null);
  };

  return (
    <div className="App">
      <h1>To-Do List</h1>
      <AddTask onTaskAdded={handleTaskAdded} />
      <TaskList onEdit={setTaskToEdit} />
      {taskToEdit && <EditTask taskToEdit={taskToEdit} onTaskUpdated={handleTaskUpdated} />}
      
    </div>
  );
}

export default App;

