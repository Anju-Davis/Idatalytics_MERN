import React, { useState, useEffect } from 'react';
import { updateTask } from '../api/taskService';

function EditTask({ taskToEdit, onTaskUpdated }) {
  const [task, setTask] = useState(taskToEdit);

  useEffect(() => {
    setTask(taskToEdit);
  }, [taskToEdit]);

  const handleChange = (e) => {
    setTask({ ...task, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await updateTask(task._id, task);
    onTaskUpdated();
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        name="title"
        value={task.title}
        onChange={handleChange}
        placeholder="Title"
        required
      />
      <input
        type="text"
        name="description"
        value={task.description}
        onChange={handleChange}
        placeholder="Description"
      />
      <select name="priority" value={task.priority} onChange={handleChange}>
        <option value="High">High</option>
        <option value="Medium">Medium</option>
        <option value="Low">Low</option>
      </select>
      <input
        type="date"
        name="dueDate"
        value={task.dueDate}
        onChange={handleChange}
      />
      <button type="submit">Update Task</button>
    </form>
  );
}

export default EditTask;
